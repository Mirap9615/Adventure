//
// Created by William on 9/6/23.
//

#include "universal.h"

static std::map<int, std::shared_ptr<Object>> all_items;
std::map<int, std::shared_ptr<Object>>& ItemsAllHook() {
    return all_items;
}

void printAllItems() {
    std::map<int, std::shared_ptr<Object>> itemList = ItemsAllHook();
    std::cout << "There are currently " << itemList.size() << " registered items." << std::endl;
    for (const auto& pair : itemList) {
        std::cout << "id: " << pair.first << " is " << pair.second->getName() << std::endl;
    }
}

void printSlowly(const std::string& text, int delay_ms) {
    for (char c : text) {
        std::cout << c;
        std::cout.flush(); // allows immediate printing
        std::this_thread::sleep_for(std::chrono::milliseconds(delay_ms));
    }
    std::cout << std::endl;
}

Settings::Settings() : detailed_combat_text(false), text_crawl_speed_letter_ms(15) {
    //std::cout << "created once and only." << std::endl;
}