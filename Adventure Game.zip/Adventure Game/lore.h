//
// Created by William on 9/6/23.
//

#ifndef FRONTIER_GAME_LORE_H
#define FRONTIER_GAME_LORE_H
#include "universal.h"

void displayInitialLore();
void choiceJob();
void choiceParty();
void returnToCity();
#endif //FRONTIER_GAME_LORE_H
